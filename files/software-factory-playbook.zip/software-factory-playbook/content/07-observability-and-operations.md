# 07 — Observability, SRE & Incident Practice

A factory that can't see its output can't improve it. Observability is pre-wired into every golden path so teams never bolt it on later.

## The three-plus-one signals

| Signal | Standard | Tools |
|---|---|---|
| Metrics | Prometheus/OpenMetrics | Prometheus + Grafana, Datadog, Cloud Monitoring |
| Logs | Structured JSON, correlation IDs | Loki, Elastic, Datadog, CloudWatch |
| Traces | **OpenTelemetry everywhere** | Tempo, Jaeger, Honeycomb, Datadog APM |
| Profiles (the +1) | Continuous profiling | Pyroscope, Parca, cloud profilers |

Non-negotiables baked into templates:

- OpenTelemetry SDK auto-instrumented; trace context propagated across every hop
- Structured logs with `trace_id`, `service`, `version`, `env`
- RED metrics (rate, errors, duration) exported per endpoint by default
- Dashboards and alerts **generated from code** alongside the service (Grafana-as-code, Terraform)

## SLOs over raw alerts

- Every `tier-1`/`tier-2` service defines **SLOs** (e.g., 99.9% availability, p95 < 300ms) with **error budgets**.
- Alert on **budget burn rate**, not on every CPU spike. Symptom-based paging; cause-based dashboards.
- Error budget policy has teeth: budget exhausted → feature work pauses in favor of reliability work. Agreed in advance, so it's policy, not a fight.

## On-call that doesn't burn people

- **You build it, you run it** — the team that ships a service carries its pager.
- Rotation hygiene: ≥ 4 people per rotation, page volume tracked, > 2 pages/night triggers a mandatory noise-reduction review.
- Every page must be **actionable and have a runbook link**. Un-actionable alerts get deleted, not snoozed.
- Tools: PagerDuty, Opsgenie, Grafana OnCall, incident.io.

## Incident practice

1. **Declare early, declare cheap.** Low friction to open an incident (slash command creates channel, doc, roles).
2. **Roles**: incident commander, comms lead, ops lead — commander coordinates, doesn't debug.
3. **Rollback first, diagnose second** for user-facing impact. Progressive delivery (doc 03) makes rollback a button.
4. **Blameless postmortems** for every SEV-1/2 within 5 business days: timeline, contributing factors (plural — never "root cause: human error"), and action items with owners and due dates.
5. **Action-item follow-through** is tracked like product work; postmortems without completed actions are theater.

## Reliability engineering cadence

| Ritual | Cadence |
|---|---|
| SLO review per service | Monthly |
| Game day / chaos experiment | Quarterly |
| DR restore drill (timed) | Quarterly |
| Dependency failure review ("what if X is down?") | Semi-annual |
| Capacity & cost review | Monthly (see FinOps in doc 08) |

## Operational readiness gate

Before a new service takes production traffic, an automated checklist verifies: SLOs defined, dashboards live, alerts wired to a rotation, runbook exists, rollback tested, backups configured. This is a template output, not a manual audit — the paved road makes it nearly free.

Next: [08 — Metrics & DORA](08-metrics-and-dora.md)
