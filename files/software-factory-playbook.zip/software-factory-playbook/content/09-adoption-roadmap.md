# 09 — 12-Month Adoption Roadmap

Don't build the whole factory before shipping through it. Build one paved road, run one team down it, then widen.

## Quarter-by-quarter

### Q1 — Foundations & first paved road
**Goal: one team ships a real service through the full factory path.**

- Stand up: VCS org standards (protected main, CODEOWNERS, rulesets), one CI system, artifact registry, one runtime environment
- Build **one** golden-path template (backend-api) with CI/CD, scanning, OTel, and GitOps deploy wired in
- Pick a **lighthouse team** (willing, mid-complexity service) and migrate them
- Baseline metrics: capture current DORA numbers before you change anything

*Exit criteria: lighthouse team deploys daily via the paved road; time-to-first-deploy for a new service < 1 day.*

### Q2 — Security spine & second wave
**Goal: supply-chain integrity on by default; 3–5 more teams onboard.**

- Artifact signing + SBOM + provenance attestation in the shared pipeline; admission policy in staging (audit mode in prod)
- Secrets migrated to a manager; CI→cloud auth moved to OIDC (kill static keys)
- Renovate/Dependabot org-wide with weekly merge cadence
- Second template (worker or frontend); template drift-update mechanism working
- Start the service catalog — every service gets an owner and a tier

*Exit criteria: 100% of paved-road artifacts signed with SBOMs; zero static cloud keys in CI; 5+ services on templates.*

### Q3 — Self-service platform & operations maturity
**Goal: infra without tickets; on-call and SLOs standardized.**

- Portal live (Backstage/Port) with scaffolding, catalog, and TechDocs
- Self-service provisioning for the top 3 ticket types (database, queue, DNS/domain)
- SLOs + burn-rate alerting for all tier-1 services; incident tooling and blameless postmortem process running
- Preview environments per PR for the main product surfaces
- First quarterly game day

*Exit criteria: infra ticket volume down 50%; every tier-1 service has SLOs, runbooks, and a rotation.*

### Q4 — Scale, measure, harden
**Goal: majority adoption; the factory measurably outperforms the old way.**

- Paved-road adoption ≥ 70% of active services; off-road teams meeting the same policy bars via policy-as-code
- Admission policies in **enforce** mode in production
- Unified platform-health dashboard (DORA + security + cost + DevEx) reviewed monthly with leadership
- DR restore drill completed and timed; error-budget policy formally adopted
- Publish the year-one before/after: lead time, CFR, time-to-first-deploy, DevEx score

*Exit criteria: DORA lead time and recovery time improved ≥ 2x vs. Q1 baseline; DevEx satisfaction trending up.*

## Team & investment guide

| Org size | Platform investment |
|---|---|
| < 30 engineers | No dedicated team — a rotating "paved road" working group + strong SaaS defaults |
| 30–100 | 2–4 person platform team |
| 100–300 | 5–10, split infra / DX / security-enablement |
| 300+ | Platform org with product management |

Rule of thumb: platform ≈ **5–8% of engineering headcount**, run as a product (doc 06).

## Common failure modes & counters

| Failure | Counter |
|---|---|
| Big-bang platform, no users for a year | Lighthouse team in Q1; ship value monthly |
| Mandated adoption of an inferior path | Make the paved road genuinely better first; measure adoption, don't decree it |
| Platform becomes a ticket queue | Self-service SLA: any repeated ticket type becomes automation next sprint |
| Security bolted on in Q4 | Signing/scanning in the *first* template (Q1–Q2) |
| Metrics theater | Every dashboard review ends with owners and experiments |
| Template rot | Automated drift updates + template CI from day one |

## The one-page summary

1. **Standardize the undifferentiated** (pipelines, security, observability) so teams can differentiate on product.
2. **Make the right way the easy way** — golden paths, self-service, policy-as-code.
3. **Small batches, always releasable** — trunk, flags, progressive delivery.
4. **Automate trust** — signed, attested, scanned artifacts; humans only where machines can't decide.
5. **Measure the system, improve monthly** — DORA + DevEx + cost on one page, with owners.

Back to [00 — Overview](00-overview.md)
