# 06 — Internal Developer Platform & Tool Stack

The platform is the factory's machinery: the self-service layer that lets product teams provision, deploy, and operate without tickets.

## Platform-as-a-product

Treat the IDP like a product with customers (your developers):

- A **roadmap** driven by developer pain, not platform-team hobbies
- **Docs and onboarding** as first-class deliverables
- **Adoption metrics** (paved-road %, time-to-first-deploy, ticket deflection)
- Regular **developer experience surveys** (quarterly, short, acted on visibly)

The fastest way to kill a platform: mandate it before it's better than the alternative.

## Reference tool stack (pick per column, don't buy everything)

| Capability | Options |
|---|---|
| Developer portal / catalog | Backstage, Port, Cortex, OpsLevel |
| Cloud | AWS / GCP / Azure (pick one primary) |
| IaC | Terraform/OpenTofu, Pulumi, Crossplane |
| Runtime | Kubernetes (EKS/GKE/AKS), ECS/Fargate, Cloud Run |
| CI/CD | see doc 03 |
| Secrets | Vault, cloud-native managers + External Secrets |
| Observability | see doc 07 |
| Feature flags | LaunchDarkly, Unleash, OpenFeature |
| Data platform | Snowflake/BigQuery/Databricks + dbt + orchestration (Airflow/Dagster) |
| Local dev | Devcontainers, Tilt, Skaffold, Docker Compose |
| AI assistance | Copilot/Claude Code-style agents + org-wide usage policy |

## Self-service surfaces

Offer the same capabilities through three doors, backed by one implementation:

1. **CLI** (`factory new`, `factory deploy`, `factory db create`) — power users
2. **Portal UI** (Backstage plugins/Port actions) — discoverability
3. **Pull requests to config repos** — auditability, GitOps-native

Everything a team can self-serve should be **scored by tier**: e.g., a `tier-1` (customer-facing, revenue-critical) service automatically gets stricter policies, mandatory on-call, and higher SLO requirements than a `tier-3` internal tool.

## AI in the factory (2026 reality)

- **Coding agents** (IDE + CLI) with an explicit policy: what data they may see, which repos they may touch, and mandatory human review on generated changes.
- **AI in the pipeline**: PR summarization, first-pass review, test generation, incident-summary drafting. Keep humans as the accountable gate.
- **Evaluation for AI features**: if your products embed LLMs, add eval suites and prompt/version tracking to the pipeline exactly like tests (promptfoo, Braintrust, LangSmith-style tooling).
- Track AI-assisted change quality separately for a while (defect rate, review time) before trusting it at higher autonomy.

## Cognitive load budget

Every tool added must remove more load than it adds. Practical tests:

- Can a new hire ship to production in **week one** using only the docs?
- Does an average service require the team to understand **fewer than ~5 platform concepts** to operate day-to-day?
- Is there exactly **one** obvious way to do the common thing?

When the answer turns no, consolidate before adding.

## Documentation system

- **Docs-as-code**: markdown in repos, rendered in the portal (Backstage TechDocs, MkDocs).
- Three doc types, deliberately separated: **tutorials/onboarding**, **how-to runbooks**, **reference/ADRs**.
- **ADRs** (architecture decision records) for one-way doors — short, numbered, immutable-with-superseding.
- Docs rot policy: pages carry owners and review dates; stale pages get flagged automatically.

Next: [07 — Observability & Operations](07-observability-and-operations.md)
