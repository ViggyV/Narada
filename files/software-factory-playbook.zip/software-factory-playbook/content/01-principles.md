# 01 — Principles & Operating Model

The factory succeeds or fails on principles, not tools. Tools change; these shouldn't.

## The seven principles

### 1. Everything as code
Infrastructure, pipelines, policies, dashboards, alerts, and docs live in version control. If it can't be code-reviewed and rolled back, it doesn't exist.

### 2. Paved roads, not gates
Make the right way the easy way. A team using the golden path gets CI/CD, security scanning, deployment, and observability *for free*. Teams may go off-road, but they own the extra work and risk. Prefer incentives over mandates.

### 3. Small batches, always releasable
Trunk-based development, feature flags, and continuous delivery. `main` is deployable at all times. Big-bang releases are a failure mode, not an event.

### 4. Shift left, but automate the shift
Security, quality, and compliance checks run in the pipeline, in the editor, and in pre-commit — not in a review meeting three weeks later. A human should only be involved when a machine can't decide.

### 5. Self-service by default
Provisioning a database, a service, a domain, or a dashboard is a pull request or a portal click — never a ticket to another team. The platform team builds products; other teams are their customers.

### 6. Measure the system, not the people
Metrics (DORA, lead time, change failure rate) evaluate the *factory's* health. The moment a metric becomes an individual performance target, it gets gamed and dies (Goodhart's law).

### 7. Continuous improvement is scheduled
Reserve real capacity (15–25%) for platform work, debt paydown, and tooling. "We'll fix it when things calm down" means never.

## Operating model

```
┌────────────────────────────────────────────────────────┐
│                    Product Teams                       │
│   (stream-aligned: own build, ship, run for a domain)  │
├────────────────────────────────────────────────────────┤
│                 Enabling Teams (rotational)            │
│   (coaching: testing, security, performance)           │
├────────────────────────────────────────────────────────┤
│                    Platform Team                       │
│   (IDP, CI/CD, golden paths, infra — run as a product) │
└────────────────────────────────────────────────────────┘
```

This mirrors the **Team Topologies** model: stream-aligned teams deliver value; the platform team reduces their cognitive load; enabling teams close skill gaps temporarily.

## Decision rules

- **Standardize** anything undifferentiated: pipelines, base images, logging, auth, secrets.
- **Leave flexible** anything close to the product: domain logic, UX, data models.
- **Two-way doors** (reversible choices) get decided fast and locally. **One-way doors** (languages, cloud, datastore) get an ADR and a review.

## Anti-patterns to reject early

- A "DevOps team" that becomes a ticket queue between dev and prod
- Standardization by memo instead of by tooling
- 100% utilization planning — leaves no room for incidents or improvement
- Metrics dashboards nobody acts on

Next: [02 — Golden Paths & Paved Roads](02-golden-paths.md)
