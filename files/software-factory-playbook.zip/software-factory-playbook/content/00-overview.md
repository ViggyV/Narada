# Software Factory Playbook — Overview

> A software factory is not a place. It is a repeatable, automated, measurable system for turning ideas into running software — where the *process* of building is engineered as deliberately as the products themselves.

## What "software factory" means here

Traditional teams treat every project as a bespoke effort: new repo layout, new pipeline, new deployment scripts, new security review. A software factory inverts that. It standardizes the *how* (paths, pipelines, guardrails, tooling) so teams can spend their creativity on the *what* (the product).

The output of the factory is not just software — it's **software plus confidence**: every artifact ships with tests passed, security scanned, provenance attested, and rollback ready.

## Core outcomes to aim for

| Outcome | Target signal |
|---|---|
| Fast flow | Idea → production in days, not months |
| Repeatability | New service scaffolded and deployed in < 1 hour |
| Safety | Every change gated by automated quality + security checks |
| Visibility | DORA metrics + cost + security posture on one dashboard |
| Autonomy | Teams self-serve infra without tickets |

## The series

| Doc | Topic |
|---|---|
| [01](01-principles.md) | Principles & operating model |
| [02](02-golden-paths.md) | Golden paths & paved roads (templates, scaffolding) |
| [03](03-source-control-and-cicd.md) | Source control, branching, CI/CD |
| [04](04-testing-and-quality.md) | Testing strategy & quality gates |
| [05](05-security-and-supply-chain.md) | Security, secrets, supply chain (SBOM, signing) |
| [06](06-platform-and-tooling.md) | Internal developer platform & tool stack |
| [07](07-observability-and-operations.md) | Observability, SRE, incident practice |
| [08](08-metrics-and-dora.md) | Metrics: DORA, SPACE, cost |
| [09](09-adoption-roadmap.md) | 12-month adoption roadmap |

## Who this is for

- **Engineering leaders** deciding what to standardize vs. leave flexible
- **Platform teams** building the paved roads
- **Product teams** who will live on those roads

Start with [01 — Principles](01-principles.md).
