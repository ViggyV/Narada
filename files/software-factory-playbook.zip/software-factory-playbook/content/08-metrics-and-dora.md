# 08 — Metrics: DORA, SPACE & Cost

You can't tune a factory you don't measure. But measure the *system*, act on trends, and never weaponize metrics against individuals.

## DORA — the four keys (plus reliability)

| Metric | Elite benchmark | What it tells you |
|---|---|---|
| Deployment frequency | On-demand / multiple per day | Batch size & pipeline health |
| Lead time for changes (commit → prod) | < 1 day | Flow efficiency |
| Change failure rate | < 5–15% | Quality of gates & testing |
| Failed deployment recovery time | < 1 hour | Rollback & incident maturity |
| (5th) Reliability / SLO attainment | Meets targets | Whether speed is sustainable |

**Collection**: derive automatically from your VCS + CD + incident tooling (Sleuth, LinearB, Swarmia, DX, or homegrown from GitHub/Argo/PagerDuty APIs). Manual reporting rots in a month.

**Interpretation rules**

- Compare a team **to its own trend**, not to other teams.
- The four move together — optimizing deploy frequency while change failure rate climbs means you're just shipping bugs faster.
- Read them quarterly at the org level, monthly at the team level.

## SPACE / developer experience

DORA measures the pipe; SPACE measures the humans:

- **S**atisfaction: quarterly DevEx survey (keep it under 10 questions, publish results and actions)
- **P**erformance: outcome metrics per team (their own KPIs, not story points)
- **A**ctivity: use only for spotting friction (e.g., PRs stuck in review), never for ranking
- **C**ommunication: review turnaround time, cross-team dependency wait time
- **E**fficiency/flow: perceived focus time, meeting load, build wait time

The highest-leverage numbers in practice: **CI duration, review turnaround, flake rate, time-to-first-deploy for new hires.** All four are platform-fixable.

## Cost (FinOps) — the factory's unit economics

- **Tag or die**: every resource carries `service`, `team`, `env` tags, enforced by policy-as-code.
- **Showback monthly** per team/service; chargeback only when the org is mature enough not to fight about it.
- Track **unit cost** (cost per request / per customer / per build minute), not just total spend — totals rise with success; unit costs shouldn't.
- CI cost is real money: cache hit rate and pipeline minutes belong on the platform dashboard.
- Tools: cloud-native cost tools, Kubecost/OpenCost, Vantage, CloudZero.

## One dashboard, one narrative

Combine on a single platform-health view:

```
Delivery:   deploy freq · lead time · CFR · recovery time
Quality:    escaped defects · flake rate · diff coverage trend
Security:   open crit/high vulns vs SLA · % signed artifacts · patch latency
Platform:   paved-road adoption % · time-to-first-deploy · DevEx score
Cost:       unit cost trend · CI minutes · idle resource %
```

Review it monthly with engineering leadership; every red trend gets an owner and an experiment, or it's just wall art.

## Goodhart guardrails

- No individual-level dashboards. Ever.
- Retire any metric that stops driving decisions.
- Pair every speed metric with a quality metric so gaming one shows up in the other.

Next: [09 — Adoption Roadmap](09-adoption-roadmap.md)
