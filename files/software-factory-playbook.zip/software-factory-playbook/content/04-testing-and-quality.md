# 04 — Testing Strategy & Quality Gates

The factory's promise is that anything reaching `main` is releasable. Testing is how that promise gets kept.

## The shape of the suite

Aim for a **testing trophy / pyramid hybrid**:

```
        ▲  E2E (few, critical journeys only)
       ▲▲  Contract & integration (the workhorses)
     ▲▲▲▲  Unit (fast, deterministic, thousands)
    ────── Static analysis (types, linting, SAST) — the free base layer
```

| Layer | Purpose | Budget in pre-merge CI |
|---|---|---|
| Static (types, lint, format) | Catch entire bug classes for free | seconds |
| Unit | Logic correctness, fast feedback | 2–4 min |
| Contract (Pact, OpenAPI/protobuf schema checks) | Services can't break each other silently | 1–2 min |
| Integration (Testcontainers) | Real DB/queue behavior without mocks-lying | 3–5 min |
| E2E (Playwright/Cypress) | 5–15 critical user journeys, post-merge | 10–20 min post-merge |

## Practices that matter more than coverage %

- **Deterministic tests or delete them.** A flaky test is worse than no test — it trains people to click "re-run." Quarantine flakes automatically (tag, skip, ticket) and track flake rate as a platform metric.
- **Test data as code.** Factories/builders, not shared fixture dumps. Never test against production data.
- **Contract tests over full-environment E2E** for service interactions — they're fast, isolated, and pinpoint the breaking side.
- **Mutation testing** (Stryker, PIT) on critical modules occasionally — it audits whether tests actually assert anything.
- **Performance budgets in CI**: bundle size, p95 latency on key endpoints, cold-start time. Regressions fail the build like any other bug.

## Quality gates (enforced by pipeline, not by meeting)

A merge is blocked unless:

1. All required checks green (build, unit, contract, lint, types)
2. No new critical/high SAST or secret findings
3. Diff coverage ≥ agreed floor on changed lines (e.g., 80%) — *diff* coverage, not total, so legacy code doesn't block progress
4. At least one qualified review (CODEOWNERS)
5. No unresolved license violations in new dependencies

Keep the gate list short and non-negotiable. Every gate you add must pay for its friction.

## Code review practice

- Small PRs (< ~400 lines changed) — review quality collapses beyond that
- Review SLA: first response within one business day; automate the nag
- Reviewers check design, correctness, and clarity; formatting and style are the linter's job, never a human comment
- AI-assisted review (e.g., LLM reviewers) as a *first pass*, never the final gate

## Non-functional testing cadence

| Type | Cadence | Tools |
|---|---|---|
| Load / soak | Pre-release for major changes, monthly baseline | k6, Gatling, Locust |
| Chaos | Quarterly game days → automated experiments | Litmus, Gremlin, AWS FIS |
| Accessibility | Every PR touching UI | axe-core in CI |
| DR restore test | Quarterly, timed, documented | your backup tooling + runbook |

Next: [05 — Security & Supply Chain](05-security-and-supply-chain.md)
