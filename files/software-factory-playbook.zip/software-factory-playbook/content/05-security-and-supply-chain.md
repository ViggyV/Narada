# 05 — Security, Secrets & Supply Chain

Modern software factories are attacked through their *pipelines* as often as their products. Security here is a build-in property, automated end to end.

## The layered model

```
Code ── Dependencies ── Build ── Artifact ── Deploy ── Runtime
 │           │            │         │           │         │
SAST      SCA/updates   hermetic  signing +   policy    runtime
secret    license       builds,   SBOM,       as code   detection,
scanning  checks        SLSA      provenance  (OPA)     least-priv
```

## Code & dependencies

- **Secret scanning** in pre-commit *and* CI *and* on the VCS host (Gitleaks, TruffleHog, GitHub secret scanning). A leaked secret is an incident: rotate first, investigate second.
- **SAST** on every PR (Semgrep, CodeQL, SonarQube). Tune rules ruthlessly — a noisy scanner gets ignored, which is worse than none.
- **SCA / dependency scanning** (Dependabot, Renovate, Snyk, OSV-Scanner) with *automated update PRs*. The practice that matters is not scanning — it's **merging updates weekly** so patching a zero-day is routine, not heroic.
- **License policy as code**: allow/deny lists checked in CI (e.g., FOSSA, license-checker), so legal review isn't a launch-day surprise.

## Build integrity (SLSA-aligned)

- **Hermetic, ephemeral builders** — no long-lived agents accumulating credentials.
- **Pinned dependencies** (lockfiles, digest-pinned base images, pinned CI actions by SHA).
- **Sign every artifact** (Sigstore/cosign) and generate **SBOMs** (Syft, CycloneDX) at build time; store them with the artifact.
- **Provenance attestation** (SLSA provenance via GitHub artifact attestations or in-toto): the deploy system verifies "this image was built by *our* pipeline from *this* commit" before admitting it to prod.
- Admission control enforces it: **unsigned or unattested images don't run** (Kyverno, OPA Gatekeeper, Sigstore policy-controller).

## Secrets & identity

- **No static secrets in code, CI variables, or laptops** where avoidable. Prefer short-lived, identity-based credentials: OIDC federation from CI to cloud (GitHub OIDC → AWS/GCP roles), workload identity in the cluster.
- Where secrets must exist: a manager (Vault, AWS Secrets Manager, GCP Secret Manager) with rotation, audit, and app-side injection (External Secrets Operator).
- **Human access**: SSO + MFA everywhere, just-in-time elevation (e.g., short-lived roles), quarterly access reviews automated from IdP data.

## Policy as code

Encode the rules once, enforce everywhere:

- **Infra policies** (OPA/Conftest, Checkov, tfsec): no public buckets, mandatory tags, encryption on.
- **Cluster policies** (Kyverno/Gatekeeper): no `latest` tags, resource limits required, non-root containers.
- **Pipeline policies**: required checks defined centrally (org rulesets), not per-repo goodwill.

This is also how the off-road teams from doc 02 stay honest: policy applies to everyone; only support differs.

## Runtime & response

- Runtime detection (Falco, GuardDuty, Defender) wired to the same alerting as ops.
- **Vulnerability SLAs**: critical 7 days, high 30 days — tracked on the same dashboard as DORA metrics so security debt is visible next to delivery speed.
- Threat modeling as a lightweight ritual: one hour at design time for any new externally-facing surface, using a simple STRIDE checklist.

## Compliance without tears

If you need SOC 2 / ISO 27001 / FedRAMP-style evidence: the factory *is* the evidence. Pipelines, signed artifacts, access logs, and policy checks generate audit trails continuously (helped by tools like Vanta/Drata). Design controls into the paved road once instead of collecting screenshots annually.

Next: [06 — Platform & Tooling](06-platform-and-tooling.md)
