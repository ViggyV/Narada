# 02 — Golden Paths & Paved Roads

A golden path is an opinionated, supported, end-to-end route from "new idea" to "running in production." It's the factory's assembly line.

## What a golden path includes

When a developer runs `factory new service --template go-api`, they should get:

1. **Repo scaffolding** — standard layout, README, CODEOWNERS, LICENSE
2. **CI/CD pipeline** — pre-wired build/test/scan/deploy workflow
3. **Containerization** — hardened base image, multi-stage Dockerfile
4. **Infra as code** — Terraform/OpenTofu module or Helm chart for the service
5. **Observability** — structured logging, metrics, tracing pre-instrumented (OpenTelemetry)
6. **Security defaults** — secret scanning, dependency scanning, SAST enabled
7. **Service catalog entry** — auto-registered in Backstage (or equivalent) with owner, tier, on-call, docs
8. **Environments** — dev/staging namespaces provisioned, prod behind promotion gate

Target: **under 60 minutes** from `factory new` to a hello-world endpoint live in staging.

## Tooling options

| Capability | Common choices |
|---|---|
| Scaffolding / templates | Backstage Software Templates, Cookiecutter, Copier, Yeoman |
| Service catalog | Backstage, Port, Cortex, OpsLevel |
| IaC modules | Terraform/OpenTofu registries, Pulumi, Crossplane compositions |
| Dev environments | Devcontainers, Nix, GitPod/Codespaces |

## Template governance

- Templates live in a `templates/` monorepo owned by the platform team.
- Every template has a **maintainer**, a **changelog**, and **automated tests** (scaffold → build → deploy in CI on every template change).
- **Drift management**: use a tool like Copier's update mechanism or Renovate-style PRs to push template updates into existing services. Never let scaffolded repos fossilize.

## Sample template inventory (start small)

1. `backend-api` — REST/gRPC service in your primary language
2. `frontend-app` — SPA/SSR app with design system wired in
3. `worker` — queue consumer / scheduled job
4. `library` — internal shared package with publishing pipeline
5. `data-pipeline` — batch/stream job with orchestration hooks

Resist making 20 templates on day one. Three excellent templates beat fifteen stale ones.

## The off-road policy

Teams can deviate — but the deal is explicit:

> **On the paved road**: platform team supports your pipeline, upgrades your base images, answers your pages about shared tooling.
> **Off-road**: you own your pipeline, your patching, your 3 a.m. mystery. You must still meet the same security and compliance bars, verified by policy-as-code (see doc 05).

Track paved-road adoption as a platform KPI (e.g., % of services on a current template version).

Next: [03 — Source Control & CI/CD](03-source-control-and-cicd.md)
