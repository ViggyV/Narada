# 03 — Source Control, Branching & CI/CD

The pipeline *is* the factory floor. Everything else feeds it or consumes it.

## Source control practices

- **Trunk-based development**: short-lived branches (< 1–2 days), merged to `main` continuously. Long-lived feature branches are where merges go to die.
- **Feature flags** decouple deploy from release. Incomplete work ships dark. (Tools: LaunchDarkly, Unleash, OpenFeature, or a homegrown config service.)
- **Protected `main`**: required status checks, required review, no force-push, linear history.
- **Conventional Commits** + automated changelog/versioning (semantic-release, release-please).
- **CODEOWNERS** routes reviews automatically; keep files small and ownership real.
- **Mono vs. multi-repo**: either works. Choose based on your tooling maturity — monorepos need investment (Bazel/Nx/Turborepo, merge queues); multi-repo needs strong templates and drift management.

## Pipeline reference architecture

```
commit → pre-merge CI ──────────► merge queue ──► main
              │                                    │
   lint · unit tests · SAST ·              build once, promote
   secret scan · license check                     │
                                                   ▼
                                        ┌── artifact registry ──┐
                                        │  (signed image + SBOM) │
                                        └───────────┬───────────┘
                                                    ▼
                                   deploy: dev → staging → canary → prod
                                        (GitOps pull, auto-rollback)
```

### Rules of the pipeline

1. **Build once, promote many.** The exact artifact tested in staging is what ships to prod. Rebuilding per-environment invalidates your testing.
2. **Fast feedback first.** Pre-merge CI under 10 minutes. Push slow suites (E2E, load) post-merge or nightly.
3. **Merge queue** (GitHub merge queue, Mergify, Bors-style) keeps `main` green under high commit volume.
4. **Ephemeral, hermetic builds.** Pinned toolchains, no snowflake build agents, cache aggressively (remote build cache).
5. **Deployment is boring.** GitOps (Argo CD / Flux) reconciles desired state; humans approve promotions, machines execute them.
6. **Progressive delivery.** Canary or blue/green with automated rollback on SLO burn (Argo Rollouts, Flagger).

## Tool stack cheat sheet

| Layer | Options |
|---|---|
| VCS host | GitHub, GitLab, Bitbucket |
| CI | GitHub Actions, GitLab CI, Buildkite, CircleCI, Jenkins (legacy) |
| Build systems (monorepo) | Bazel, Nx, Turborepo, Pants |
| Artifact registry | GitHub Packages, Artifactory, ECR/GAR/ACR, Harbor |
| CD / GitOps | Argo CD, Flux, Spinnaker, Octopus |
| Progressive delivery | Argo Rollouts, Flagger |
| Environments | Kubernetes + vcluster/namespaces, Nomad, ECS |

## Environment strategy

- **Ephemeral preview environments** per PR for anything with a UI or API contract — reviewers click a link, not check out a branch.
- **Staging mirrors prod** in topology, not in scale. Synthetic + masked data only.
- **Production access** is break-glass, audited, and time-boxed. Day-to-day changes go through the pipeline, period.

## Definition of done for a change

A change is done when it is: merged to main, deployed to production behind its flag, observable (metrics/logs/traces emitting), and its flag cleanup ticket exists.

Next: [04 — Testing & Quality](04-testing-and-quality.md)
