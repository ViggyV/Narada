# Software Factory Playbook

A 10-part field guide to building a software factory: golden paths, CI/CD,
supply-chain security, platform engineering, observability, and DORA metrics.

## Read it

- **As a website**: open `index.html` in any browser (double-click works —
  it's fully self-contained, markdown renderer inlined, no build step, no server).
- **As markdown**: browse `content/` — files are numbered `00` → `09` and
  cross-linked, so they also read fine on GitHub.

## Publish it (optional)

The site is a single static file, so any static host works:

- **GitHub Pages**: Settings → Pages → deploy from branch, folder
  `/software-factory-playbook`.
- Or copy `index.html` anywhere (Netlify, S3, nginx).

## Edit it

The markdown files in `content/` are the source of truth. `index.html`
embeds a copy of each doc; if you edit the markdown, regenerate the site
or edit the embedded copies inside `index.html` (search for the doc slug).
